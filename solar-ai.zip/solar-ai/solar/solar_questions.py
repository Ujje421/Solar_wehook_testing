QUESTIONS = [
    {"id": "monthly_bill", "text": "What is your monthly electricity bill?"},
    {"id": "roof_type", "text": "What is your roof type? (Concrete / Metal)"},
    {"id": "city", "text": "Which city is your home located in?"}
]
