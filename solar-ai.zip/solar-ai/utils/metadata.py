def build_metadata(source="whatsapp"):
    return {"source": source}
